feature_extarctobj=__import__('feature-extract')

print("******* Running Test Cases of feature extraction ***********")
feature_extarctobj.test()